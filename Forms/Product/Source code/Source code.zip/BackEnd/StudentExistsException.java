package BackEnd;

public class StudentExistsException extends Exception {
    public StudentExistsException() { super(); }
}
